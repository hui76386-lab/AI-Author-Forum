AI Author Forum ZIP import test package
- 10 articles total
- Articles 01-05 use DOCX
- Articles 06-10 use Markdown
- Each article contains 10 chapters
- All imported articles must remain drafts
